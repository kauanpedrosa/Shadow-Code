package com.example.secureme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.secureme.R
import com.example.secureme.ui.theme.Preto
import com.example.secureme.ui.theme.Branco

@Composable
fun CreditsScreen(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Preto
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Parte superior - Créditos
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Créditos",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = Branco
                )

                Spacer(modifier = Modifier.height(32.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.DarkGray),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(
                            text = "Desenvolvedores:",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Branco
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        val devs = listOf(
                            "Kauan Pedrosa Marques da Silva - RA 2401743",
                            "Murilo Leone Fernandes - RA 2401735",
                            "Rafael Lima Reis - RA 2401699",
                            "Yuri Souza Tito - RA 2401782"
                        )

                        devs.forEach {
                            Text(
                                text = it,
                                fontSize = 16.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Parte inferior - Logo + Direitos
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(32.dp))

                Image(
                    painter = painterResource(id = R.drawable.logoshadowcode),
                    contentDescription = "Logo do Grupo",
                    modifier = Modifier
                        .height(100.dp)
                        .padding(bottom = 8.dp)
                )

                Text(
                    text = "ShadowCodeGroup © 2025",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = "Todos os direitos reservados.\nProjeto acadêmico sem fins lucrativos.",
                    fontSize = 12.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
