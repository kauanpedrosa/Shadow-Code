package com.example.secureme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavBackStackEntry
import com.example.secureme.R
import com.example.secureme.ui.theme.Preto
import com.example.secureme.ui.theme.Branco

@Composable
fun Screen3(navController: NavController, backStackEntry: NavBackStackEntry) {
    val nome = backStackEntry.arguments?.getString("nome") ?: "Desconhecido"
    val imagemKey = backStackEntry.arguments?.getString("imagem") ?: "seguranca_yuri"

    // Mapeamento seguro para recursos
    val imagemId = when (imagemKey) {
        "seguranca_yuri" -> R.drawable.seguranca_yuri
        "seguranca_rafa" -> R.drawable.seguranca_rafa
        "ic_seguranca2_background" -> R.drawable.ic_seguranca2_background
        else -> R.drawable.seguranca_yuri
    }

    var selectedPeriod by remember { mutableStateOf("") }
    val periodOptions = listOf("Manhã", "Tarde", "Noite", "Integral")

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Preto
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Período de Serviço",
                fontSize = 22.sp,
                color = Branco
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Exibe imagem do segurança
            Image(
                painter = painterResource(id = imagemId),
                contentDescription = nome,
                modifier = Modifier
                    .height(180.dp)
                    .fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = "Segurança: $nome", fontSize = 18.sp, color = Branco)

            Spacer(modifier = Modifier.height(24.dp))

            periodOptions.forEach { period ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = selectedPeriod == period,
                        onClick = { selectedPeriod = period }
                    )
                    Text(text = period, color = Branco)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (selectedPeriod.isNotEmpty()) {
                        // Continua passando a string da imagem, e não o ID
                        navController.navigate("screen4/$nome/$imagemKey/$selectedPeriod")
                    }
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = selectedPeriod.isNotEmpty()
            ) {
                Text("Confirmar período")
            }
        }
    }
}
