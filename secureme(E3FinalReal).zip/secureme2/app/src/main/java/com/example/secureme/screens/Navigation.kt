package com.example.secureme.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") { HomeScreen(navController) }

        composable("screen2") { Screen2(navController) }

        // Tela 3 recebe nome e imagem do segurança
        composable(
            "screen3/{nome}/{imagem}",
            arguments = listOf(
                navArgument("nome") { type = NavType.StringType },
                navArgument("imagem") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            Screen3(navController, backStackEntry)
        }

        // Tela 4 recebe nome, imagem e período
        composable(
            "screen4/{nome}/{imagem}/{periodo}",
            arguments = listOf(
                navArgument("nome") { type = NavType.StringType },
                navArgument("imagem") { type = NavType.StringType },
                navArgument("periodo") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            Screen4(navController, backStackEntry)
        }

        composable("credits") { CreditsScreen(navController) }
    }
}
