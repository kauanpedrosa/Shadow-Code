package com.example.secureme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.secureme.R
import com.example.secureme.ui.theme.Preto
import com.example.secureme.ui.theme.Purple40


@Composable
fun HomeScreen(navController: NavController) {
    Surface(
        modifier = Modifier.fillMaxSize(), // ❌ sem .padding aqui
        color = Preto // sua cor personalizada
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp), // ✅ padding aqui dentro!
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            Image(
                painter = painterResource(id = R.drawable.ic_seguranca_background),
                contentDescription = "Logo do App",
                modifier = Modifier.size(500.dp)
            )

            Text(
                text = "SecureMe",
                fontSize = 50.sp,
                fontWeight = FontWeight.Normal,
                color = Purple40
            )

            Text(
                text = "O seu melhor app de segurança privada",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.background
            )

            Spacer(modifier = Modifier.height(30.dp))

            Button(
                onClick = { navController.navigate("screen2") },
                shape = RectangleShape,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .shadow(1.dp, RoundedCornerShape(4.dp))
            ) {
                Text(text = "Proteja-se", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

