package com.example.secureme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.rememberScrollState
import androidx.navigation.NavController
import com.example.secureme.R
import com.example.secureme.ui.theme.Preto
import com.example.secureme.ui.theme.Branco

@Composable
fun Screen2(navController: NavController) {
    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Preto
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Escolha seu tipo de segurança",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Branco
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Segurança Pessoal
            Image(
                painter = painterResource(id = R.drawable.seguranca_yuri),
                contentDescription = "Segurança Pessoal",
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    navController.navigate("screen3/Yuri Tito/seguranca_yuri")
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Text("Escolher Segurança Pessoal")
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Segurança Empresarial
            Image(
                painter = painterResource(id = R.drawable.seguranca_rafa),
                contentDescription = "Segurança Empresarial",
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    navController.navigate("screen3/Rafael Lima/seguranca_rafa")
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Text("Escolher Segurança Empresarial")
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Segurança Residencial
            Image(
                painter = painterResource(id = R.drawable.ic_seguranca2_background),
                contentDescription = "Segurança Residencial",
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = {
                    navController.navigate("screen3/Bruno Gomes/ic_seguranca2_background")
                },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
            ) {
                Text("Escolher Segurança Residencial")
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
