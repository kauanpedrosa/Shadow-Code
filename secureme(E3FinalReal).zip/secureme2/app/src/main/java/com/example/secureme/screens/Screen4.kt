package com.example.secureme.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavController
import com.example.secureme.R
import com.example.secureme.ui.theme.Preto
import com.example.secureme.ui.theme.Branco

@Composable
fun Screen4(navController: NavController, backStackEntry: NavBackStackEntry) {
    val nome = backStackEntry.arguments?.getString("nome") ?: "Desconhecido"
    val imagemKey = backStackEntry.arguments?.getString("imagem") ?: "seguranca_yuri"
    val periodo = backStackEntry.arguments?.getString("periodo") ?: "Não informado"

    // Mapeamento da string para o ID da imagem
    val imagemId = when (imagemKey) {
        "seguranca_yuri" -> R.drawable.seguranca_yuri
        "seguranca_rafa" -> R.drawable.seguranca_rafa
        "ic_seguranca2_background" -> R.drawable.ic_seguranca2_background
        else -> R.drawable.seguranca_yuri
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Preto
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Resumo da Escolha",
                fontSize = 22.sp,
                color = Branco
            )

            Spacer(modifier = Modifier.height(24.dp))

            Image(
                painter = painterResource(id = imagemId),
                contentDescription = "Imagem do segurança",
                modifier = Modifier
                    .height(200.dp)
                    .fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text("Nome: $nome", fontSize = 18.sp, color = Branco)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Período: $periodo", fontSize = 18.sp, color = Branco)

            Spacer(modifier = Modifier.height(30.dp))

            Button(
                onClick = { navController.navigate("credits") },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text("Ir para Créditos")
            }
        }
    }
}
